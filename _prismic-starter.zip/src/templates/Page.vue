<template lang="pug">
  layout
    prismic-image(:field='page.image', v-if='page.image')
    prismic-rich-text(:field='page.title')
    prismic-rich-text(:field='page.body')
</template>

<script>
export default {
  computed: {
    page () {
      return this.$context.node
    }
  }
}
</script>
