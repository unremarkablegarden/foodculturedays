// This is the main.js file. Import global CSS and scripts here.
// The Client API can be used here. Learn more: gridsome.org/docs/client-api
// import Vuex from 'vuex'
import { common } from 'prismic-vue/components'

import DefaultLayout from '~/layouts/Default.vue'

export default function (Vue, { router, head, isClient, appOptions }) {
  // Vue.use(Vuex)
  // appOptions.store = new Vuex.Store({
  //   state: {
  //     lang: 'en-gb'
  //   },
  //   mutations: {
  //     setLang (state, l) {
  //       console.log('store = ' + l)
  //       state.lang = l
  //     }
  //   }
  // })

  Vue.component('Layout', DefaultLayout)

  // Add attributes to HTML tag
  var userLang = navigator.language || navigator.userLanguage;
  head.htmlAttrs = { lang: userLang.toLowerCase() }

  Vue.prototype.$prismic = {
    linkResolver() { /* ... */}
  }

  Object.entries(common).forEach(([_, component]) => {
    Vue.component(component.name, component)
  })
}
