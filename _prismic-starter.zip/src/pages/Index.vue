<template lang="pug">
  layout
    Loader

    g-image(alt='', src='https://images.prismic.io/foodculturedays/99305ed2-6288-407d-95c0-f67a4f681581_logo.svg?auto=compress,format')

    Menu

</template>

<script>
import Menu from '~/components/Menu.vue'
import Loader from '~/components/Loader.vue'

export default {
  components: {
    Menu, Loader
  },
  metaInfo: {
    title: 'Home'
  },
  data () {
    return {
    }
  },
  computed: {
    lang () {
      // return this.$store.state.lang
      return this.$context.lang
    },
  }
}
</script>

<style lang="scss">
.home-links a {
  margin-right: 1rem;
}
</style>
