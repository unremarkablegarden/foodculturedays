<template lang="pug">
  .layout
    Lang
    slot
</template>


<static-query>
query {
  metadata {
    siteName
  }
}
</static-query>

<script>
import Lang from '~/components/Lang.vue'

export default {
  components: {
    Lang
  },
  created () {
    // if in the root path redirect to user's language index page
    if (window.location.pathname == '/') {
      let to
      if (this.lang == 'en-gb') {
        to = '/en/'
      } else {
        to = '/fr/'
      }
      this.$router.push(to)
    }
  },
  computed: {
    lang () {
      // return this.$store.state.lang
      return this.$context.lang
    }
  }
}
</script>

<style lang="scss">
@font-face {
    font-family: 'CE';
    src: url('../assets/ce-i.woff2') format('woff2'),
         url('../assets/ce-i.woff') format('woff');
    font-weight: 500;
    font-style: italic;
}

@font-face {
    font-family: 'D';
    src: url('../assets/d.woff2') format('woff2'),
         url('../assets/d.woff') format('woff');
    font-weight: normal;
    font-style: normal;
}

@font-face {
    font-family: 'CE';
    src: url('../assets/ce.woff2') format('woff2'),
         url('../assets/ce.woff') format('woff');
    font-weight: 500;
    font-style: normal;
}


#lang {
  button {
    opacity: 0.5;
    &.is-active {
      opacity: 1;
    }
  }
}
body {
  font-family: 'D', -apple-system,system-ui,BlinkMacSystemFont,"Segoe UI",Roboto,"Helvetica Neue",Arial,sans-serif;
  margin:0;
  padding:0;
  line-height: 1.5;
}
i, em {
  font-family: 'CE', Times, serif;
}

.layout {
  max-width: 760px;
  margin: 0 auto;
  padding-left: 20px;
  padding-right: 20px;
}
</style>
