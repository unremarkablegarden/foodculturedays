<template lang="pug">
  #menu
    p menu
    //- g-link.nav__link(v-for="item in menu", :key="item.title[lang]", :to="item.to[lang]") {{ item.title[lang] }}
</template>

<script>
export default {
  name: 'Menu',
  data () {
    return {
      menu: [
        { title: ['Home', 'Le Home'], to: ['/en/', '/fr/'] },
        { title: ['About', 'Le About'], to: ['/en/about/', '/fr/about/'] },
      ],
      lang: 0,
      langs: [
        'en-gb',
        'fr-ch'
      ],
      langpath: [
        'en',
        'fr'
      ]
    }
  },
  created () {
    // set the language to french if its in the user browser setting
    if (window.location.pathname.includes('fr')) {
      this.lang = 1
    }
  }
}
</script>

<style class="scss">
</style>