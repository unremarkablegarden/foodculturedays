<template lang="pug">
  #lang
    button(@click="changeLang(0)", v-bind:class="activeLang(0)") EN
    button(@click="changeLang(1)", v-bind:class="activeLang(1)") FR
</template>

<script>
export default {
  name: 'Lang',
  data () {
    return {
      lang: 0,
      langs: [
        'en-gb',
        'fr-ch'
      ],
      langpath: [
        'en',
        'fr'
      ]
    }
  },
  created () {
    // set the language to french if its in the user browser setting
    if (window.location.pathname.includes('fr')) {
      this.lang = 1
    }
  },
  methods: {
    changeLang (l) {
      let path = '/' + this.langpath[l] + window.location.pathname.substring(3)
      document.documentElement.lang = this.langs[l]
      // this.$store.commit('setLang', this.langs[l])
      this.lang = l
      if (window.location.pathname !== path) {
        this.$router.push(path)
      }
    },
    activeLang (l) {
      if (l === this.lang) return 'is-active'
    }
  }
}
</script>

<style class="scss">
</style>