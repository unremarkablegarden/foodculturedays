<template lang="pug">
  #loader
    g-image(alt='', src='https://images.prismic.io/foodculturedays/96ab8abe-b823-43f5-8501-ce8709a4c44e_blob.svg?auto=compress,format')
    //- g-image(alt='', src='https://images.prismic.io/foodculturedays/5aac43f3-77bd-4181-9ec3-f208eb67f934_blob-mobile.svg?auto=compress,format')
</template>