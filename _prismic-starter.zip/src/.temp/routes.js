export default [
  {
    path: "/fr/home/",
    component: () => import(/* webpackChunkName: "page--src--templates--page-vue" */ "/Users/euklides/Development/foodculturedays/fcd-gridsome/src/templates/Page.vue")
  },
  {
    path: "/en/home/",
    component: () => import(/* webpackChunkName: "page--src--templates--page-vue" */ "/Users/euklides/Development/foodculturedays/fcd-gridsome/src/templates/Page.vue")
  },
  {
    path: "/en/about/",
    component: () => import(/* webpackChunkName: "page--src--templates--page-vue" */ "/Users/euklides/Development/foodculturedays/fcd-gridsome/src/templates/Page.vue")
  },
  {
    path: "/old-about/",
    component: () => import(/* webpackChunkName: "page--src--pages--old-about-vue" */ "/Users/euklides/Development/foodculturedays/fcd-gridsome/src/pages/OldAbout.vue")
  },
  {
    path: "/fr/",
    component: () => import(/* webpackChunkName: "page--src--pages--index-vue" */ "/Users/euklides/Development/foodculturedays/fcd-gridsome/src/pages/Index.vue")
  },
  {
    path: "/en/",
    component: () => import(/* webpackChunkName: "page--src--pages--index-vue" */ "/Users/euklides/Development/foodculturedays/fcd-gridsome/src/pages/Index.vue")
  },
  {
    name: "404",
    path: "/404/",
    component: () => import(/* webpackChunkName: "page--node-modules--gridsome--app--pages--404-vue" */ "/Users/euklides/Development/foodculturedays/fcd-gridsome/node_modules/gridsome/app/pages/404.vue")
  },
  {
    name: "home",
    path: "/",
    component: () => import(/* webpackChunkName: "page--src--pages--index-vue" */ "/Users/euklides/Development/foodculturedays/fcd-gridsome/src/pages/Index.vue")
  },
  {
    name: "*",
    path: "*",
    component: () => import(/* webpackChunkName: "page--node-modules--gridsome--app--pages--404-vue" */ "/Users/euklides/Development/foodculturedays/fcd-gridsome/node_modules/gridsome/app/pages/404.vue")
  }
]

