export default {
  "trailingSlash": true,
  "pathPrefix": "",
  "titleTemplate": "%s - FOODCULTRE days",
  "siteUrl": "",
  "version": "0.7.13",
  "catchLinks": true
}