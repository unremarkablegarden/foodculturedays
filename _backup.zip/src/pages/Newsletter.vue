<template lang="pug">
  layout
    #newsletter
      h1 Newsletter
</template>

<style lang="scss">
#newsletter {
  margin-top: 1rem;
}
</style>