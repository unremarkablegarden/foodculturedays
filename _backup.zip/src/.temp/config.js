export default {
  "trailingSlash": true,
  "pathPrefix": "",
  "titleTemplate": "%s - FOODCULTURE days",
  "siteUrl": "",
  "version": "0.7.13",
  "catchLinks": true
}